import json
import os
import openai
from PIL import Image
import io
import boto3
from botocore.exceptions import ClientError
import base64
import time
from fpdf import FPDF
from rembg import remove
import cv2
import numpy as np
from pdf2image import convert_from_bytes
import fitz  # PyMuPDF
import subprocess
from concurrent.futures import ThreadPoolExecutor

# Initialize OpenAI API
openai.api_key = os.environ['OPENAI_API_KEY']

# Initialize AWS S3 client
s3 = boto3.client('s3')

# S3 bucket name
S3_BUCKET = os.environ['S3_BUCKET_NAME']

# Load prompts
with open("ycai_prompt.txt", "r") as file:
    SYSTEM_PROMPT = file.read()

with open("pdf_prompt.txt", "r") as file:
    PDF_PROMPT = file.read()

# Usage data
usage_data = {}
USAGE_DATA_FILE = "/tmp/usage_data.json"

def lambda_handler(event, context):
    # Parse the incoming request
    http_method = event['httpMethod']
    path = event['path']
    body = json.loads(event['body']) if 'body' in event else {}

    # Route the request to the appropriate function
    if http_method == 'POST':
        if path == '/chat':
            return chat(body)
        elif path == '/pdf':
            return generate_pdf(body)
        elif path == '/upscale':
            return upscale_image(body)
        elif path == '/remove_background':
            return remove_background(body)
        elif path == '/vectorize':
            return vectorize_image(body)
        elif path == '/usage':
            return get_usage(body)
    
    # If no matching route is found
    return {
        'statusCode': 404,
        'body': json.dumps({'error': 'Not found'})
    }

def chat(body):
    user_input = body.get('message', '')
    user_id = body.get('user_id', '')

    if not check_usage_limit(user_id, 'responses'):
        return {
            'statusCode': 403,
            'body': json.dumps({'error': 'Usage limit reached'})
        }

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_input}
            ]
        )

        bot_response = response['choices'][0]['message']['content']

        update_usage(user_id, 'responses')

        return {
            'statusCode': 200,
            'body': json.dumps({'response': bot_response})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def generate_pdf(body):
    content = body.get('content', '')
    user_id = body.get('user_id', '')
    background_image = body.get('background_image', '')
    logo_image = body.get('logo_image', '')

    if not check_usage_limit(user_id, 'responses'):
        return {
            'statusCode': 403,
            'body': json.dumps({'error': 'Usage limit reached'})
        }

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": PDF_PROMPT},
                {"role": "user", "content": content}
            ]
        )

        ai_content = response['choices'][0]['message']['content']

        pdf_content = generate_pdf_content(ai_content, background_image, logo_image)

        pdf_key = f"pdfs/{user_id}_{int(time.time())}.pdf"
        s3.put_object(Bucket=S3_BUCKET, Key=pdf_key, Body=pdf_content)

        update_usage(user_id, 'responses')

        return {
            'statusCode': 200,
            'body': json.dumps({'pdf_url': f"https://{S3_BUCKET}.s3.amazonaws.com/{pdf_key}"})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def upscale_image(body):
    image_data = body.get('image', '')
    user_id = body.get('user_id', '')

    if not check_usage_limit(user_id, 'images'):
        return {
            'statusCode': 403,
            'body': json.dumps({'error': 'Usage limit reached'})
        }

    try:
        image = Image.open(io.BytesIO(base64.b64decode(image_data)))
        upscaled_image = process_image(image, remove_background=False)

        img_buffer = io.BytesIO()
        upscaled_image.save(img_buffer, format='PNG')
        img_buffer.seek(0)

        img_key = f"upscaled/{user_id}_{int(time.time())}.png"
        s3.put_object(Bucket=S3_BUCKET, Key=img_key, Body=img_buffer)

        update_usage(user_id, 'images')

        return {
            'statusCode': 200,
            'body': json.dumps({'image_url': f"https://{S3_BUCKET}.s3.amazonaws.com/{img_key}"})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def remove_background(body):
    image_data = body.get('image', '')
    user_id = body.get('user_id', '')

    if not check_usage_limit(user_id, 'images'):
        return {
            'statusCode': 403,
            'body': json.dumps({'error': 'Usage limit reached'})
        }

    try:
        image = Image.open(io.BytesIO(base64.b64decode(image_data)))
        processed_image = process_image(image, remove_background=True)

        img_buffer = io.BytesIO()
        processed_image.save(img_buffer, format='PNG')
        img_buffer.seek(0)

        img_key = f"no_bg/{user_id}_{int(time.time())}.png"
        s3.put_object(Bucket=S3_BUCKET, Key=img_key, Body=img_buffer)

        update_usage(user_id, 'images')

        return {
            'statusCode': 200,
            'body': json.dumps({'image_url': f"https://{S3_BUCKET}.s3.amazonaws.com/{img_key}"})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def vectorize_image(body):
    image_data = body.get('image', '')
    user_id = body.get('user_id', '')

    if not check_usage_limit(user_id, 'images'):
        return {
            'statusCode': 403,
            'body': json.dumps({'error': 'Usage limit reached'})
        }

    try:
        image = Image.open(io.BytesIO(base64.b64decode(image_data)))
        svg_content = jpg_to_svg(image)

        svg_key = f"vectorized/{user_id}_{int(time.time())}.svg"
        s3.put_object(Bucket=S3_BUCKET, Key=svg_key, Body=svg_content)

        update_usage(user_id, 'images')

        return {
            'statusCode': 200,
            'body': json.dumps({'svg_url': f"https://{S3_BUCKET}.s3.amazonaws.com/{svg_key}"})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

def get_usage(body):
    user_id = body.get('user_id', '')
    
    try:
        user_usage = usage_data.get(user_id, {'responses': 0, 'images': 0})
        return {
            'statusCode': 200,
            'body': json.dumps(user_usage)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }

# Helper functions

def process_image(image, remove_background=False):
    img_array = np.array(image)
    
    if remove_background:
        img_array = remove(img_array)
    
    resized_img = cv2.resize(img_array, (3000, 3000))
    return Image.fromarray(resized_img)

def generate_pdf_content(content, background_image, logo_image):
    pdf = PDF()
    pdf.add_page()

    if background_image:
        pdf.background_image = io.BytesIO(base64.b64decode(background_image))
    if logo_image:
        pdf.logo_image = io.BytesIO(base64.b64decode(logo_image))

    pdf.set_font("Arial", size=12)
    pdf.multi_cell(0, 10, txt=content)

    pdf_buffer = io.BytesIO()
    pdf.output(pdf_buffer)
    pdf_buffer.seek(0)
    return pdf_buffer.getvalue()

def jpg_to_svg(image):
    # Convert to black and white
    bw_image = image.convert('L')
    bw_image = bw_image.point(lambda x: 0 if x < 128 else 255, '1')

    # Save as PBM
    pbm_buffer = io.BytesIO()
    bw_image.save(pbm_buffer, format='PPM')
    pbm_buffer.seek(0)

    # Use potrace to convert PBM to SVG
    svg_content = subprocess.run(['potrace', '-s', '-o', '-'], input=pbm_buffer.getvalue(), capture_output=True, text=True).stdout

    return svg_content

class PDF(FPDF):
    def __init__(self):
        super().__init__()
        self.background_image = None
        self.logo_image = None

    def header(self):
        if self.background_image:
            self.image(self.background_image, x=0, y=0, w=self.w, h=self.h)
        if self.logo_image:
            self.image(self.logo_image, x=10, y=8, w=33)

# Usage tracking functions

def load_usage_data():
    global usage_data
    try:
        s3.download_file(S3_BUCKET, 'usage_data.json', USAGE_DATA_FILE)
        with open(USAGE_DATA_FILE, 'r') as f:
            usage_data = json.load(f)
    except ClientError:
        usage_data = {}

def save_usage_data():
    with open(USAGE_DATA_FILE, 'w') as f:
        json.dump(usage_data, f)
    s3.upload_file(USAGE_DATA_FILE, S3_BUCKET, 'usage_data.json')

def update_usage(user_id, usage_type):
    if user_id not in usage_data:
        usage_data[user_id] = {'responses': 0, 'images': 0}
    usage_data[user_id][usage_type] += 1
    save_usage_data()

def check_usage_limit(user_id, usage_type):
    if user_id not in usage_data:
        return True
    # Implement your usage limit logic here
    return True  # For now, always return True

# Load usage data at the start
load_usage_data()